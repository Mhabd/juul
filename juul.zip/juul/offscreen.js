chrome.runtime.onMessage.addListener(async (message) => {
  if (message.target !== 'offscreen' || message.type !== 'fetch-csrf') return;

  try {
    const response = await fetch(message.url);
    const html = await response.text();
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const csrfToken = doc.querySelector('meta[name="csrf-token"]')?.dataset.token;

    chrome.runtime.sendMessage({
      type: 'csrf-result',
      status: 'success',
      csrfToken: csrfToken,
      messageId: message.messageId
    });
  } catch (error) {
    chrome.runtime.sendMessage({
      type: 'csrf-result',
      status: 'error',
      error: error.message,
      messageId: message.messageId
    });
  }
});
